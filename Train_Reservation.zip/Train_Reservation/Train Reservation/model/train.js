class Train {
    constructor(id, code, name, type) {
        this.id = id
        this.code=code
        this.name = name
        this.type = type    
    }
}

module.exports = Train