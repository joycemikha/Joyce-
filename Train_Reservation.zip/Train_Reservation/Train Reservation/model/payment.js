class Payment {
    constructor(id, code, type) {
        this.id = id
        this.code=code
        this.type = type    
    }
}

module.exports = Payment