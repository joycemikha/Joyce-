class Pay {
    constructor(PaymentsID, ReservePassangersID, ReserveTripId) {
        this.PaymentsID = PaymentsID
        this.ReservePassangersID=ReservePassangersID
        this.ReserveTripId = ReserveTripId
    }
}

module.exports = Pay